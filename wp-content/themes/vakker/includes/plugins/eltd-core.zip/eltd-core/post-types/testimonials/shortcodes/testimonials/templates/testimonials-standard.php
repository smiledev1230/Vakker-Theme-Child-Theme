<div class="eltd-testimonial-content" id="eltd-testimonials-<?php echo esc_attr( $current_id ) ?>">
    <?php if ( has_post_thumbnail() ) { ?>
        <div class="eltd-testimonial-image">
            <?php echo get_the_post_thumbnail( get_the_ID(), 'full' ); ?>
        </div>
    <?php } ?>
	<div class="eltd-testimonial-text-holder">
        <span class="eltd-testimonial-mark">”</span>
        <?php if ( ! empty( $title ) ) { ?>
			<h2 itemprop="name" class="eltd-testimonial-title entry-title"><?php echo esc_html( $title ); ?></h2>
		<?php } ?>
		<?php if ( ! empty( $text ) ) { ?>
			<p class="eltd-testimonial-text"><?php echo esc_html( $text ); ?></p>
		<?php } ?>
		<?php if ( ! empty( $author ) ) { ?>
			<div class="eltd-testimonial-author">
				<h4 class="eltd-testimonials-author-name"><?php echo esc_html( $author ); ?></h4>
				<?php if ( ! empty( $position ) ) { ?>
					<h6 class="eltd-testimonials-author-job"><?php echo esc_html( $position ); ?></h6>
				<?php } ?>
			</div>
		<?php } ?>
	</div>
</div>