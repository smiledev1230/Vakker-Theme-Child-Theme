<div class="eltd-ps-info-item eltd-ps-content-item">
    <?php the_content(); ?>
</div>