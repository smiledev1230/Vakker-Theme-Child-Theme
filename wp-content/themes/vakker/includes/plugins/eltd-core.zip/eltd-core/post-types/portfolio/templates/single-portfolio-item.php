<?php

get_header();

vakker_eltd_get_title();

do_action('vakker_eltd_before_main_content');

eltd_core_get_single_portfolio();

get_footer();