<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div class="eltd-pli-text-holder">

	<?php if (get_post_meta(get_the_ID(), 'portfolio_simple', true) == 'yes') { ?>
		<span class="eltd-frame top-left-v"></span>
		<span class="eltd-frame bottom-right-v"></span>
		<span class="eltd-frame top-left-h"></span>
		<span class="eltd-frame bottom-right-h"></span>
	<?php } ?>

	<div class="eltd-pli-text-wrapper">
		<div class="eltd-pli-text">
			<div class="eltd-pli-text-inner">
				<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/title', $item_style, $params); ?>

				<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/category', $item_style, $params); ?>

				<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/images-count', $item_style, $params); ?>

				<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/excerpt', $item_style, $params); ?>
			</div>
		</div>
	</div>
</div>