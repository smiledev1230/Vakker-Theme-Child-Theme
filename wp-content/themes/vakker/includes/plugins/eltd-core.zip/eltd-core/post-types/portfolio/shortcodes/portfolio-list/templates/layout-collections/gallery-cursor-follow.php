<?php echo eltd_core_get_cpt_shortcode_module_template_part('portfolio', 'portfolio-list', 'parts/image', $item_style, $params); ?>

<div class="eltd-pli-image-overlay"></div>