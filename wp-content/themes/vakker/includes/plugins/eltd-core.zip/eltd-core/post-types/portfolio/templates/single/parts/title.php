<div class="eltd-ps-info-item eltd-ps-content-title">
    <h2 class="eltd-ps-info-main-title"><?php the_title(); ?></h2>
</div>