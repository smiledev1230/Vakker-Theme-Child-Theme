<div class="eltd-team-single-info-holder">
    <div class="eltd-grid-row">
        <div class="eltd-ts-image-holder eltd-grid-col-6">
            <?php the_post_thumbnail(); ?>
        </div>
        <div class="eltd-ts-details-holder eltd-grid-col-6">
            <h2 itemprop="name" class="eltd-name entry-title"><?php the_title(); ?></h2>
            <h6 class="eltd-position"><?php echo esc_html($position); ?> </h6>

            <?php eltd_core_get_cpt_single_module_template_part('templates/single/parts/content', 'team', '', $params); ?>

            <div class="eltd-ts-bio-holder">
                <?php if (!empty($birth_date)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-calendar-full"></span>
                        <h6 class="eltd-ts-bio-info"><?php echo esc_html($birth_date); ?></h6>
                    </div>
                <?php } ?>
                <?php if (!empty($education)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-bookmark"></span>
                        <h6 class="eltd-ts-bio-info"><?php echo esc_html($education); ?></h6>
                    </div>
                <?php } ?>
                <?php if (!empty($phone)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-phone-handset"></span>
                        <h6 class="eltd-ts-bio-info"><?php echo esc_html($phone); ?></h6>
                    </div>
                <?php } ?>
                <?php if (!empty($email)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-envelope"></span>
                        <h6 itemprop="email"
                            class="eltd-ts-bio-info"><?php echo sanitize_email(esc_html($email)); ?></h6>
                    </div>
                <?php } ?>
                <?php if (!empty($address)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-apartment"></span>
                        <h6 class="eltd-ts-bio-info"><?php echo esc_html($address); ?></h6>
                    </div>
                <?php } ?>
                <?php if (!empty($resume)) { ?>
                    <div class="eltd-ts-info-row">
                        <span aria-hidden="true" class="eltd-ts-bio-icon lnr lnr-file-empty"></span>
                        <a href="<?php echo esc_url($resume); ?>" download target="_blank"><h6
                                    class="eltd-ts-bio-info"><?php echo esc_html__('Download Resume', 'eltd-core'); ?></h6>
                        </a>
                    </div>
                <?php } ?>
                <?php if (!empty($social_icons)) {
                    echo '<div class="eltd-ts-social-holder"><span class="eltd-ts-social-text">' .esc_html__('follow me:', 'eltd-core') . '</span>';
                    foreach ($social_icons as $social_icon) {
                        echo wp_kses_post($social_icon);
                    }
                    echo '</div>';
                } ?>
            </div>
        </div>
    </div>
</div>