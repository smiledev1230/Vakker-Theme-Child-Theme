(function($) {
	'use strict';
	
	var stackedImages = {};
	eltd.modules.stackedImages = stackedImages;

	stackedImages.eltdInitItemShowcase = eltdInitStackedImages;


	stackedImages.eltdOnDocumentReady = eltdOnDocumentReady;
	
	$(document).ready(eltdOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdOnDocumentReady() {
		eltdInitStackedImages();
	}
	
	/**
	 * Init item showcase shortcode
	 */
	function eltdInitStackedImages() {
		var stackedImages = $('.eltd-stacked-images-holder');

		if (stackedImages.length) {
			stackedImages.each(function(){
				var thisStackedImages = $(this),
					itemImage = thisStackedImages.find('.eltd-si-images');

				//logic
				thisStackedImages.animate({opacity:1},200);

				setTimeout(function(){
					thisStackedImages.appear(function(){
						itemImage.addClass('eltd-appeared');
					},{accX: 0, accY: eltdGlobalVars.vars.eltdElementAppearAmount});
				},100);
			});
		}
	}
	
})(jQuery);