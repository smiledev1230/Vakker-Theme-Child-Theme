<div class="eltd-uncovering-sections">
	<ul class="eltd-us-wrapper curtains" data-image-holder-name=".eltd-uss-image-holder" data-fade-element-name=".eltd-fss-shadow">
		<?php echo do_shortcode($content); ?>
	</ul>
    <div class="eltd-fss-shadow"></div>
</div>