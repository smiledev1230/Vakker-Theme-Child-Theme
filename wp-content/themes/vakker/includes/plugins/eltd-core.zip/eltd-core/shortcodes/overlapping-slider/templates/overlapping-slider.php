<div class="eltd-overlapping-slider-holder">
    <div class="eltd-grid">
        <div class="eltd-overlapping-slider-inner eltd-owl-slider" <?php echo vakker_eltd_get_inline_attrs($slider_data); ?>>
            <?php foreach ($slider_items as $item): ?>
                <div class="eltd-overlapping-slider-item clearfix">
                    <div class="eltd-osi-image">
                        <?php echo wp_get_attachment_image($item['image'], 'full'); ?>
                    </div>
                    <div class="eltd-osi-text-holder">
                        <div class="eltd-osi-text-holder-inner">
                            <div class="eltd-osi-text-wrapper">
                                <<?php echo esc_attr($title_tag); ?> class="eltd-osi-title"> <?php echo esc_html($item['title']) ?> </<?php echo esc_attr($title_tag); ?>>
                                <div class="eltd-osi-text"> <?php echo esc_html($item['text']); ?> </div>
                                <?php if(!empty($item['link'])) : ?>
                                    <?php echo vakker_eltd_execute_shortcode('eltd_button', array(
                                        'type'  => 'solid',
                                        'link'  => $item['link'],
                                        'text'  => $item['button_text']
                                    )); ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>