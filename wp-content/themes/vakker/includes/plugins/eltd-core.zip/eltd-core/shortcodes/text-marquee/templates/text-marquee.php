<div class="eltd-text-marquee" <?php echo vakker_eltd_inline_style( $text_styles ); ?>>
	<span class="eltd-marquee-element eltd-original-text"><?php echo esc_html( $text ) ?></span>
	<span class="eltd-marquee-element eltd-aux-text"><?php echo esc_html( $text ) ?></span>
</div>  