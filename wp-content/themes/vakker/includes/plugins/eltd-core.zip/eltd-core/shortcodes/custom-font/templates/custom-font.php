<<?php echo esc_attr( $title_tag ); ?> class="eltd-custom-font-holder <?php echo esc_attr( $holder_classes ); ?>" <?php vakker_eltd_inline_style( $holder_styles ); ?> <?php echo vakker_eltd_get_inline_attrs( $holder_data ); ?>>
	<?php echo wp_kses_post( $title ); ?>
</<?php echo esc_attr( $title_tag ); ?>>