<div class="eltd-price-table eltd-item-space <?php echo esc_attr($holder_classes); ?>">
	<div class="eltd-pt-inner" <?php echo vakker_eltd_get_inline_style($holder_styles); ?>>
		<ul>
			<li class="eltd-pt-title-holder">
				<h4 class="eltd-pt-title" <?php echo vakker_eltd_get_inline_style($title_styles); ?>><?php echo esc_html($title); ?></h4>
			</li>
			<li class="eltd-pt-prices">
				<span class="eltd-pt-price" <?php echo vakker_eltd_get_inline_style($price_styles); ?>><?php echo esc_html($currency) . esc_html($price); ?></span>
			</li>
			<li class="eltd-pt-content">
				<?php echo do_shortcode($content); ?>
			</li>
			<?php 
			if(!empty($button_text)) { ?>
				<li class="eltd-pt-button">
                    <div class="eltd-pt-button-inner">
                        <?php echo vakker_eltd_get_button_html(array(
                            'link' => $link,
                            'text' => $button_text,
                            'type' => 'simple',
                        )); ?>
                    </div>
				</li>				
			<?php } ?>
		</ul>
	</div>
</div>