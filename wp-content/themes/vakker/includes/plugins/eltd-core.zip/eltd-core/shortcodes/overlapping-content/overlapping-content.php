<?php
namespace ElatedCore\CPT\Shortcodes\OverlappingContent;

use ElatedCore\Lib;

class OverlappingContent implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltd_overlapping_content';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Overlapping Content', 'eltd-core' ),
					'base'                      => $this->getBase(),
					'icon'                      => 'icon-wpb-overlapping-content extended-custom-icon',
					'category'                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'eltd-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'eltd-core' )
						),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'title_tag',
                            'heading'     => esc_html__( 'Title Tag', 'eltd-core' ),
                            'value'       => array_flip(vakker_eltd_get_title_tag(true))
                        ),
                        array(
                            'type' => 'attach_image',
                            'param_name' => 'image',
                            'heading' => esc_html__('Image', 'eltd-core'),
                            'description' => esc_html__('Select image from media library', 'eltd-core')
                        ),
                        array(
                            'type' => 'textfield',
                            'param_name' => 'title',
                            'heading'    => esc_html__('Title', 'eltd-core'),
                        ),
                        array(
                            'type' => 'textarea',
                            'param_name' => 'text',
                            'heading'    => esc_html__('Text', 'eltd-core'),
                        )
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'custom_class'   => '',
            'title_tag'      => 'div',
            'image'          => '',
            'title'          => '',
            'text'          => ''
		);
		$params = shortcode_atts( $args, $atts );

		$params['holder_classes'] = $this->getHolderClasses( $params );

        $html = eltd_core_get_shortcode_module_template_part( 'templates/overlapping-content', 'overlapping-content', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
		
		return implode( ' ', $holderClasses );
	}
	

}