<div class="eltd-full-screen-image-slider <?php echo esc_attr($holder_classes); ?>">
	<div class="eltd-fsis-slider eltd-owl-slider" <?php echo vakker_eltd_get_inline_attrs($slider_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
	<div class="eltd-fsis-thumb-nav eltd-fsis-prev-nav"></div>
	<div class="eltd-fsis-thumb-nav eltd-fsis-next-nav"></div>
	<div class="eltd-fsis-slider-mask"></div>
</div>