<?php $icon_html = vakker_eltd_icon_collections()->renderIcon($icon, $icon_pack, $params); ?>
<div class="eltd-icon-list-holder <?php echo esc_attr($holder_classes); ?>" <?php echo vakker_eltd_get_inline_style($holder_styles); ?>>
    <?php if(!empty($link)) { ?>
        <a href="<?php echo esc_url($link) ?>" target="_blank">
    <?php } ?>
        <div class="eltd-il-icon-holder">
            <?php echo wp_kses_post($icon_html); ?>
        </div>
        <p class="eltd-il-text" <?php echo vakker_eltd_get_inline_style($title_styles); ?>><?php echo esc_html($title); ?></p>
    <?php if(!empty($link)) { ?>
        </a>
    <?php } ?>
</div>