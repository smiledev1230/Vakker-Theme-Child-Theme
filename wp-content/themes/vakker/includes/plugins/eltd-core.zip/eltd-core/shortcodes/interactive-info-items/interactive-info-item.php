<?php
namespace ElatedCore\CPT\Shortcodes\InteractiveInfoItems;

use ElatedCore\Lib;

class InteractiveInfoItem implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'eltd_interactive_info_item';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Interactive Info Item', 'eltd-core' ),
					'base'                      => $this->base,
					'icon'                      => 'icon-wpb-interactive-info-item extended-custom-icon',
					'category'                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'allowed_container_element' => 'vc_row',
					'as_child'                  => array( 'only' => 'eltd_interactive_info_items' ),
					'params'                    => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'eltd-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'eltd-core' )
						),
						array(
							'type'        => 'textfield',
							'param_name'  => 'title',
							'heading'     => esc_html__( 'Title', 'eltd-core' ),
							'save_always' => true
						),
						array(
							'type'       => 'colorpicker',
							'param_name' => 'title_color',
							'heading'    => esc_html__( 'Title Color', 'eltd-core' ),
							'dependency' => array( 'element' => 'title', 'not_empty' => true )
						),
                        array(
                            'type'       => 'attach_image',
                            'param_name' => 'initial_icon',
                            'heading'    => esc_html__('Initial Icon', 'eltd-core')
                        ),
                        array(
                            'type'       => 'attach_image',
                            'param_name' => 'hover_icon',
                            'heading'    => esc_html__('Hover Icon', 'eltd-core')
                        ),
                        array(
                            'type'        => 'textarea',
                            'param_name'  => 'text',
                            'heading'     => esc_html__( 'Text', 'eltd-core' ),
                            'save_always' => true
                        ),
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'custom_class'             => '',
			'content_background_color' => '',
			'title'                    => '',
			'title_color'              => '',
            'initial_icon'             => '',
            'hover_icon'               => '',
            'text'                     => ''
		);
		$params = shortcode_atts( $args, $atts );
		
		$params['content']             = preg_replace( '#^<\/p>|<p>$#', '', $content ); // delete p tag before and after content
		$params['holder_classes']      = $this->getHolderClasses( $params );
		$params['title_styles']        = $this->getTitleStyles( $params );

		$html = eltd_core_get_shortcode_module_template_part( 'templates/interactive-info-item', 'interactive-info-items', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
		
		return implode( ' ', $holderClasses );
	}

	
	private function getTitleStyles( $params ) {
		$itemStyle = array();
		
		if ( ! empty( $params['title_color'] ) ) {
			$itemStyle[] = 'color: ' . $params['title_color'];
		}
		
		return implode( ';', $itemStyle );
	}


}