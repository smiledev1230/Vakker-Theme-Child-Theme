<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/overlapping-content/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/overlapping-content/overlapping-content.php';