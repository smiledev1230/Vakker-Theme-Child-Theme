(function($) {
	'use strict';
	
	var expandedGallery = {};
	eltd.modules.expandedGallery = expandedGallery;

	expandedGallery.eltdInitExpandedGallery = eltdInitExpandedGallery;


	expandedGallery.eltdOnDocumentReady = eltdOnDocumentReady;
	
	$(document).ready(eltdOnDocumentReady);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdOnDocumentReady() {
		eltdInitExpandedGallery();
	}

	/*
	 **	Init Expanded Gallery shortcode
	 */
	function eltdInitExpandedGallery(){
		var holder = $('.eltd-expanded-gallery');

		if(holder.length){
			holder.each(function() {
				var thisHolder = $(this),
					thisHolderImages = thisHolder.find('.eltd-eg-image');

				thisHolder.find('.eltd-eg-image:nth-child('+Math.ceil(thisHolderImages.length / 2)+')').addClass('eltd-eg-middle-item');

				thisHolder.appear(function() {
					thisHolder.find('.eltd-eg-middle-item').addClass('eltd-eg-show');

					setTimeout(function(){
						thisHolder.find('.eltd-eg-middle-item').prev().addClass('eltd-eg-show');
						thisHolder.find('.eltd-eg-middle-item').next().addClass('eltd-eg-show');
					},250);

					if (thisHolder.hasClass('eltd-eg-five')) {
						setTimeout(function(){
							thisHolder.find('.eltd-eg-middle-item').prev().prev().addClass('eltd-eg-show');
							thisHolder.find('.eltd-eg-middle-item').next().next().addClass('eltd-eg-show');
						},500);
					}
				}, {accX: 0, accY: eltdGlobalVars.vars.eltdElementAppearAmount});
			});
		}
	}
	
})(jQuery);