<?php
namespace ElatedCore\CPT\Shortcodes\OverlappingSlider;

use ElatedCore\Lib;

class OverlappingSlider implements Lib\ShortcodeInterface {
	private $base;
	
	public function __construct() {
		$this->base = 'eltd_overlapping_slider';
		
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Overlapping Slider', 'eltd-core' ),
					'base'                      => $this->getBase(),
					'icon'                      => 'icon-wpb-overlapping-slider extended-custom-icon',
					'category'                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'allowed_container_element' => 'vc_row',
					'params'                    => array(
						array(
							'type'        => 'textfield',
							'param_name'  => 'custom_class',
							'heading'     => esc_html__( 'Custom CSS Class', 'eltd-core' ),
							'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'eltd-core' )
						),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'title_tag',
                            'heading'     => esc_html__( 'Title Tag', 'eltd-core' ),
                            'value'       => array_flip(vakker_eltd_get_title_tag(true))
                        ),
                        array(
                            'type' => 'param_group',
                            'heading' => esc_html__('Items', 'eltd-core'),
                            'param_name' => 'slider_items',
                            'value' => '',
                            'params' => array(
                                array(
                                    'type' => 'attach_image',
                                    'param_name' => 'image',
                                    'heading' => esc_html__('Image', 'eltd-core'),
                                    'description' => esc_html__('Select image from media library', 'eltd-core')
                                ),
                                array(
                                    'type' => 'textfield',
                                    'param_name' => 'title',
                                    'heading'    => esc_html__('Title', 'eltd-core'),
                                ),
                                array(
                                    'type' => 'textarea',
                                    'param_name' => 'text',
                                    'heading'    => esc_html__('Text', 'eltd-core'),
                                ),
                                array(
                                    'type' => 'textfield',
                                    'param_name'    => 'link',
                                    'heading'       => esc_html__('Button Link', 'eltd-core')
                                ),
                                array(
                                    'type' => 'textfield',
                                    'param_name'    => 'button_text',
                                    'heading'       => esc_html__('Button Text', 'eltd-core')
                                )
                            )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_loop',
                            'heading'     => esc_html__( 'Enable Slider Loop', 'eltd-core' ),
                            'value'       => array_flip( vakker_eltd_get_yes_no_select_array( false, true ) ),
                            'save_always' => true,
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_autoplay',
                            'heading'     => esc_html__( 'Enable Slider Autoplay', 'eltd-core' ),
                            'value'       => array_flip( vakker_eltd_get_yes_no_select_array( false, true ) ),
                            'save_always' => true,
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed',
                            'heading'     => esc_html__( 'Slide Duration', 'eltd-core' ),
                            'description' => esc_html__( 'Default value is 5000 (ms)', 'eltd-core' ),
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        ),
                        array(
                            'type'        => 'textfield',
                            'param_name'  => 'slider_speed_animation',
                            'heading'     => esc_html__( 'Slide Animation Duration', 'eltd-core' ),
                            'description' => esc_html__( 'Speed of slide animation in milliseconds. Default value is 600.', 'eltd-core' ),
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_navigation',
                            'heading'     => esc_html__( 'Enable Slider Navigation Arrows', 'eltd-core' ),
                            'value'       => array_flip( vakker_eltd_get_yes_no_select_array( false ) ),
                            'save_always' => true,
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        ),
                        array(
                            'type'        => 'dropdown',
                            'param_name'  => 'slider_pagination',
                            'heading'     => esc_html__( 'Enable Slider Pagination', 'eltd-core' ),
                            'value'       => array_flip( vakker_eltd_get_yes_no_select_array( false ) ),
                            'save_always' => true,
                            'group'       => esc_html__( 'Slider Settings', 'eltd-core' )
                        )
					)
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
		$args   = array(
			'custom_class'   => '',
            'title_tag'      => 'div',
            'slider_items'   => '',
            'slider_loop'             => 'yes',
            'slider_autoplay'         => 'yes',
            'slider_speed'            => '5000',
            'slider_speed_animation'  => '600',
            'slider_navigation'       => 'no',
            'slider_pagination'       => 'no'
		);
		$params = shortcode_atts( $args, $atts );

        $params['slider_items'] = vc_param_group_parse_atts($atts['slider_items']);

		$params['holder_classes'] = $this->getHolderClasses( $params );
        $params['slider_data']    = $this->getSliderData( $params );

        $html = eltd_core_get_shortcode_module_template_part( 'templates/overlapping-slider', 'overlapping-slider', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
		
		return implode( ' ', $holderClasses );
	}

    private function getSliderData( $params ) {
        $slider_data = array();

        $slider_data['data-number-of-items']        = '1';
        $slider_data['data-enable-loop']            = ! empty( $params['slider_loop'] ) ? $params['slider_loop'] : '';
        $slider_data['data-enable-autoplay']        = ! empty( $params['slider_autoplay'] ) ? $params['slider_autoplay'] : '';
        $slider_data['data-slider-speed']           = ! empty( $params['slider_speed'] ) ? $params['slider_speed'] : '5000';
        $slider_data['data-slider-speed-animation'] = ! empty( $params['slider_speed_animation'] ) ? $params['slider_speed_animation'] : '600';
        $slider_data['data-enable-navigation']      = ! empty( $params['slider_navigation'] ) ? $params['slider_navigation'] : '';
        $slider_data['data-enable-pagination']      = ! empty( $params['slider_pagination'] ) ? $params['slider_pagination'] : '';

        return $slider_data;
    }
	

}