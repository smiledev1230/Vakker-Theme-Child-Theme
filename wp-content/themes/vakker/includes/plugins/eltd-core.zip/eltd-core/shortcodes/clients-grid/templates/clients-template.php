<div <?php vakker_eltd_class_attribute($holder_classes); ?>>
    <?php echo do_shortcode($content); ?>
</div>