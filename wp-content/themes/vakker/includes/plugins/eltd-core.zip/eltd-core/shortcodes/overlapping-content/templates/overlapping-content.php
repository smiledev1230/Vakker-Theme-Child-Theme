<div class="eltd-overlapping-content-holder">
    <div class="eltd-grid">
        <div class="eltd-overlapping-content-inner">
            <div class="eltd-overlapping-content-item clearfix">
                <div class="eltd-oc-image">
                    <?php echo wp_get_attachment_image($image, 'full'); ?>
                </div>
                <div class="eltd-oc-text-holder">
                    <div class="eltd-oc-text-holder-inner">
                        <div class="eltd-oc-text-wrapper">
                            <<?php echo esc_attr($title_tag); ?> class="eltd-oc-title"> <?php echo esc_html($title) ?> </<?php echo esc_attr($title_tag); ?>>
                            <div class="eltd-oc-text"> <?php echo esc_html($text); ?> </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>