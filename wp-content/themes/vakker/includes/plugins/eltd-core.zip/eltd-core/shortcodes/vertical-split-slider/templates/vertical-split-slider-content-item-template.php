<div class="eltd-vss-ms-section" <?php echo vakker_eltd_get_inline_attrs($content_data); ?> <?php vakker_eltd_inline_style($content_style);?>>
	<?php echo do_shortcode($content); ?>
</div>