(function ($) {
	'use strict';
	
	var fullScreenImageSlider = {};
	eltd.modules.fullScreenImageSlider = fullScreenImageSlider;
	
	
	fullScreenImageSlider.eltdOnWindowLoad = eltdOnWindowLoad;
	
	$(window).load(eltdOnWindowLoad);
	
	/*
	 All functions to be called on $(document).ready() should be in this function
	 */
	function eltdOnWindowLoad() {
		eltdInitFullScreenImageSlider();
	}
	
	/**
	 * Init Full Screen Image Slider Shortcode
	 */
	function eltdInitFullScreenImageSlider() {
		var holder = $('.eltd-fsis-slider');
		
		if (holder.length) {
			holder.each(function () {
				var sliderHolder = $(this),
					mainHolder = sliderHolder.parent(),
					prevThumbNav = mainHolder.children('.eltd-fsis-prev-nav'),
					nextThumbNav = mainHolder.children('.eltd-fsis-next-nav'),
					maskHolder = mainHolder.children('.eltd-fsis-slider-mask');
				
				mainHolder.addClass('eltd-fsis-is-init');
				
				eltdImageBehavior(sliderHolder);
				eltdPrevNextImageBehavior(sliderHolder, prevThumbNav, nextThumbNav, -1); // -1 is arbitrary value because 0 can be index of item
				
				sliderHolder.on('drag.owl.carousel', function () {
					setTimeout(function () {
						if (!maskHolder.hasClass('eltd-drag') && !mainHolder.hasClass('eltd-fsis-active')) {
							maskHolder.addClass('eltd-drag');
						}
					}, 200);
				});
				
				sliderHolder.on('dragged.owl.carousel', function () {
					setTimeout(function () {
						if (maskHolder.hasClass('eltd-drag')) {
							maskHolder.removeClass('eltd-drag');
						}
					}, 300);
				});
				
				sliderHolder.on('translate.owl.carousel', function (e) {
					eltdPrevNextImageBehavior(sliderHolder, prevThumbNav, nextThumbNav, e.item.index);
				});
				
				sliderHolder.on('translated.owl.carousel', function () {
					eltdImageBehavior(sliderHolder);
					
					setTimeout(function () {
						maskHolder.removeClass('eltd-drag');
					}, 300);
				});
			});
		}
	}
	
	function eltdImageBehavior(sliderHolder) {
		var activeItem = sliderHolder.find('.owl-item.active'),
			imageHolder = sliderHolder.find('.eltd-fsis-item');
		
		imageHolder.removeClass('eltd-fsis-content-image-init');
		
		eltdResetImageBehavior(sliderHolder);
		
		if (activeItem.length) {
			var activeImageHolder = activeItem.find('.eltd-fsis-item'),
				activeItemImage = activeImageHolder.children('.eltd-fsis-image');
			
			setTimeout(function () {
				activeImageHolder.addClass('eltd-fsis-content-image-init');
			}, 100);
			
			activeItemImage.off().on('mouseenter', function () {
				activeImageHolder.addClass('eltd-fsis-image-hover');
			}).on('mouseleave', function () {
				activeImageHolder.removeClass('eltd-fsis-image-hover');
			}).on('click', function () {
				if (activeImageHolder.hasClass('eltd-fsis-active-image')) {
					sliderHolder.trigger('play.owl.autoplay');
					sliderHolder.parent().removeClass('eltd-fsis-active');
					activeImageHolder.removeClass('eltd-fsis-active-image');
				} else {
					sliderHolder.trigger('stop.owl.autoplay');
					sliderHolder.parent().addClass('eltd-fsis-active');
					activeImageHolder.addClass('eltd-fsis-active-image');
				}
			});
			
			//Close on escape
			$(document).keyup(function (e) {
				if (e.keyCode === 27) { //KeyCode for ESC button is 27
					sliderHolder.trigger('play.owl.autoplay');
					sliderHolder.parent().removeClass('eltd-fsis-active');
					activeImageHolder.removeClass('eltd-fsis-active-image');
				}
			});
		}
	}
	
	function eltdPrevNextImageBehavior(sliderHolder, prevThumbNav, nextThumbNav, itemIndex) {
		var activeItem = itemIndex === -1 ? sliderHolder.find('.owl-item.active') : $(sliderHolder.find('.owl-item')[itemIndex]),
			prevItemImage = activeItem.prev().find('.eltd-fsis-image').css('background-image'),
			nextItemImage = activeItem.next().find('.eltd-fsis-image').css('background-image');
		
		if (prevItemImage.length) {
			prevThumbNav.css({'background-image': prevItemImage});
		}
		
		if (nextItemImage.length) {
			nextThumbNav.css({'background-image': nextItemImage});
		}
	}
	
	function eltdResetImageBehavior(sliderHolder) {
		var imageHolder = sliderHolder.find('.eltd-fsis-item');
		
		if (imageHolder.length) {
			imageHolder.removeClass('eltd-fsis-active-image');
		}
	}
	
})(jQuery);