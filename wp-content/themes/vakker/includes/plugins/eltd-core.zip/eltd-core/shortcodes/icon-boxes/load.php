<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/icon-boxes/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/icon-boxes/icon-boxes.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/icon-boxes/icon-box.php';