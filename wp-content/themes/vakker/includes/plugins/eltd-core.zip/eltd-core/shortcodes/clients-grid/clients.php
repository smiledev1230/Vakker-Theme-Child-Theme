<?php
namespace ElatedCore\CPT\Shortcodes\Clients;

use ElatedCore\Lib;

/**
 * Class Clients
 */
class Clients implements Lib\ShortcodeInterface {
    private $base;

    function __construct() {
        $this->base = 'eltd_clients_grid';
        add_action('vc_before_init', array($this, 'vcMap'));
    }

    public function getBase() {
        return $this->base;
    }

    public function vcMap() {
        vc_map(array(
            'name'                    => esc_html__('Clients Grid', 'eltd-core'),
            'eltd-core',
            'base'                    => $this->base,
            'as_parent'               => array('only' => 'eltd_client'),
            'content_element'         => true,
            'category'                => esc_html__('by ELATED', 'eltd-core'),
            'icon'                    => 'icon-wpb-clients extended-custom-icon',
            'show_settings_on_create' => true,
            'params'                  => array(
                array(
                    'type'        => 'dropdown',
                    'admin_label' => true,
                    'heading'     => esc_html__('Columns', 'eltd-core'),
                    'param_name'  => 'columns',
                    'value'       => array(
                        esc_html__('One', 'eltd-core')   => '1',
                        esc_html__('Two', 'eltd-core')   => '2',
                        esc_html__('Three', 'eltd-core') => '3',
                        esc_html__('Four', 'eltd-core')  => '4',
                        esc_html__('Five', 'eltd-core')  => '5',
                        esc_html__('Six', 'eltd-core')   => '6'
                    ),
                    'save_always' => true,
                    'description' => ''
                ),
                array(
                    'type'        => 'checkbox',
                    'heading'     => 'Disable Separators',
                    'param_name'  => 'disable_separator',
                    'value' => array(esc_html__('Disable separator between client items?', 'eltd-core') => 'yes'),
                    'dependency' => array( 'element' => 'columns', 'value' => array( '2', '3', '4', '5', '6' ) ),
                    'admin_label' => true
                ),
            ),
            'js_view'                 => 'VcColumnView'

        ));
    }

    public function render($atts, $content = null) {

        $args   = array(
            'columns' => '',
            'disable_separator' => ''

        );
        $params = shortcode_atts($args, $atts);

        $params['holder_classes']  = $this->getHolderClasses($params);
        extract($params);
        $params['content'] = $content;
        $html = '';

        $html = eltd_core_get_shortcode_module_template_part('templates/clients-template', 'clients-grid', '', $params);

        return $html;

    }

    private function getHolderClasses($params) {
        $classes   = array('eltd-clients clearfix');
        $classes[] = '';
        $columns = $params['columns'];


            switch ($columns) {
                case 1:
                    $classes[] = 'eltd-clients-one-columns';
                    break;
                case 2:
                    $classes[] = 'eltd-clients-two-columns';
                    break;
                case 3:
                    $classes[] = 'eltd-clients-three-columns';
                    break;
                case 4:
                    $classes[] = 'eltd-clients-four-columns';
                    break;
                case 5:
                    $classes[] = 'eltd-clients-five-columns';
                    break;
                case 6:
                    $classes[] = 'eltd-clients-six-columns';
                    break;
                default:
                    $classes[] = 'eltd-clients-two-columns';
                    break;
            }

        if($params['disable_separator'] !== '') {
            $classes[] = 'separator-disabled';
        }

        return $classes;
    }

}
