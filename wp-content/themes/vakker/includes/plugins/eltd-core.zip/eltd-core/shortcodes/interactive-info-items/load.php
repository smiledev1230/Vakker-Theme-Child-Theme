<?php

include_once ELATED_CORE_SHORTCODES_PATH . '/interactive-info-items/functions.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/interactive-info-items/interactive-info-items.php';
include_once ELATED_CORE_SHORTCODES_PATH . '/interactive-info-items/interactive-info-item.php';