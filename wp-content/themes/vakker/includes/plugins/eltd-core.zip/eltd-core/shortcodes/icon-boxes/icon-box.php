<?php
namespace ElatedCore\CPT\Shortcodes\IconBoxes;

use ElatedCore\Lib;

class IconBox implements Lib\ShortcodeInterface {
	private $base;
	
	function __construct() {
		$this->base = 'eltd_icon_box';
		add_action( 'vc_before_init', array( $this, 'vcMap' ) );
	}
	
	public function getBase() {
		return $this->base;
	}
	
	public function vcMap() {
		if ( function_exists( 'vc_map' ) ) {
			vc_map(
				array(
					'name'                      => esc_html__( 'Elated Icon Box', 'eltd-core' ),
					'base'                      => $this->base,
					'icon'                      => 'icon-wpb-icon-box extended-custom-icon',
					'category'                  => esc_html__( 'by ELATED', 'eltd-core' ),
					'allowed_container_element' => 'vc_row',
					'as_child'                  => array( 'only' => 'eltd_icon_boxes' ),
                    'params'                    => array_merge(
                        array(
                            array(
                                'type'        => 'textfield',
                                'param_name'  => 'custom_class',
                                'heading'     => esc_html__( 'Custom CSS Class', 'eltd-core' ),
                                'description' => esc_html__( 'Style particular content element differently - add a class name and refer to it in custom CSS', 'eltd-core' )
                            ),
                        ),
                        vakker_eltd_icon_collections()->getVCParamsArray(),
                        array(
                            array(
                                'type'        => 'textfield',
                                'param_name'  => 'title',
                                'heading'     => esc_html__( 'Title', 'eltd-core' ),
                            ),
                            array(
                                'type'        => 'textarea',
                                'param_name'  => 'text',
                                'heading'     => esc_html__( 'Text', 'eltd-core' ),
                            ),
                            array(
                                'type'       => 'dropdown',
                                'param_name' => 'icon_type',
                                'heading'    => esc_html__( 'Icon Type', 'eltd-core' ),
                                'value'      => array(
                                    esc_html__( 'Normal', 'eltd-core' ) => 'eltd-normal',
                                    esc_html__( 'Circle', 'eltd-core' ) => 'eltd-circle',
                                    esc_html__( 'Square', 'eltd-core' ) => 'eltd-square'
                                ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'dropdown',
                                'param_name' => 'icon_size',
                                'heading'    => esc_html__( 'Icon Size', 'eltd-core' ),
                                'value'      => array(
                                    esc_html__( 'Medium', 'eltd-core' )     => 'eltd-icon-medium',
                                    esc_html__( 'Tiny', 'eltd-core' )       => 'eltd-icon-tiny',
                                    esc_html__( 'Small', 'eltd-core' )      => 'eltd-icon-small',
                                    esc_html__( 'Large', 'eltd-core' )      => 'eltd-icon-large',
                                    esc_html__( 'Very Large', 'eltd-core' ) => 'eltd-icon-huge'
                                ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'textfield',
                                'param_name' => 'custom_icon_size',
                                'heading'    => esc_html__( 'Custom Icon Size (px)', 'eltd-core' ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'textfield',
                                'param_name' => 'shape_size',
                                'heading'    => esc_html__( 'Shape Size (px)', 'eltd-core' ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'colorpicker',
                                'param_name' => 'icon_color',
                                'heading'    => esc_html__( 'Icon Color', 'eltd-core' ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'colorpicker',
                                'param_name' => 'icon_background_color',
                                'heading'    => esc_html__( 'Icon Background Color', 'eltd-core' ),
                                'dependency' => array(
                                    'element' => 'icon_type',
                                    'value'   => array( 'eltd-square', 'eltd-circle' )
                                ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'colorpicker',
                                'param_name' => 'icon_border_color',
                                'heading'    => esc_html__( 'Icon Border Color', 'eltd-core' ),
                                'dependency' => array(
                                    'element' => 'icon_type',
                                    'value'   => array( 'eltd-square', 'eltd-circle' )
                                ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                            array(
                                'type'       => 'textfield',
                                'param_name' => 'icon_border_width',
                                'heading'    => esc_html__( 'Border Width (px)', 'eltd-core' ),
                                'dependency' => array(
                                    'element' => 'icon_type',
                                    'value'   => array( 'eltd-square', 'eltd-circle' )
                                ),
                                'group'      => esc_html__( 'Icon Settings', 'eltd-core' )
                            ),
                        )
                    )
				)
			);
		}
	}
	
	public function render( $atts, $content = null ) {
        $default_atts   = array(
			'custom_class'                => '',
			'title'                       => '',
			'text'                        => '',
            'icon_type'                   => 'eltd-normal',
            'icon_size'                   => 'eltd-icon-medium',
            'custom_icon_size'            => '',
            'shape_size'                  => '',
            'icon_color'                  => '#ddd',
            'icon_background_color'       => '',
            'icon_border_color'           => '',
            'icon_border_width'           => '',
		);
        $default_atts = array_merge( $default_atts, vakker_eltd_icon_collections()->getShortcodeParams() );
        $params       = shortcode_atts( $default_atts, $atts );
		
		$params['holder_classes']      = $this->getHolderClasses( $params );
        $params['icon_parameters'] = $this->getIconParameters( $params );

        $html = eltd_core_get_shortcode_module_template_part( 'templates/icon-box', 'icon-boxes', '', $params );
		
		return $html;
	}
	
	private function getHolderClasses( $params ) {
		$holderClasses = array();
		
		$holderClasses[] = ! empty( $params['custom_class'] ) ? esc_attr( $params['custom_class'] ) : '';
		
		return implode( ' ', $holderClasses );
	}

    private function getIconParameters( $params ) {
        $params_array = array();

        if ( empty( $params['custom_icon'] ) ) {
            $iconPackName = vakker_eltd_icon_collections()->getIconCollectionParamNameByKey( $params['icon_pack'] );

            $params_array['icon_pack']     = $params['icon_pack'];
            $params_array[ $iconPackName ] = $params[ $iconPackName ];

            if ( ! empty( $params['icon_size'] ) ) {
                $params_array['size'] = $params['icon_size'];
            }

            if ( ! empty( $params['custom_icon_size'] ) ) {
                $params_array['custom_size'] = vakker_eltd_filter_px( $params['custom_icon_size'] ) . 'px';
            }

            if ( ! empty( $params['icon_type'] ) ) {
                $params_array['type'] = $params['icon_type'];
            }

            if ( ! empty( $params['shape_size'] ) ) {
                $params_array['shape_size'] = vakker_eltd_filter_px( $params['shape_size'] ) . 'px';
            }

            if ( ! empty( $params['icon_border_color'] ) ) {
                $params_array['border_color'] = $params['icon_border_color'];
            }

            if ( $params['icon_border_width'] !== '' ) {
                $params_array['border_width'] = vakker_eltd_filter_px( $params['icon_border_width'] ) . 'px';
            }

            if ( ! empty( $params['icon_background_color'] ) ) {
                $params_array['background_color'] = $params['icon_background_color'];
            }

            $params_array['icon_color'] = $params['icon_color'];

        }

        return $params_array;
    }
	

}