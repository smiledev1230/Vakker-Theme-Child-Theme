<a itemprop="url" href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($target); ?>" <?php vakker_eltd_inline_style($button_styles); ?> <?php vakker_eltd_class_attribute($button_classes); ?> <?php echo vakker_eltd_get_inline_attrs($button_data); ?> <?php echo vakker_eltd_get_inline_attrs($button_custom_attrs); ?>>
    <?php if($type != 'simple') { ?>
        <span class="eltd-btn-cover"></span>
    <?php } ?>
    <span class="eltd-btn-text"><?php echo esc_html($text); ?></span>
    <?php echo vakker_eltd_icon_collections()->renderIcon($icon, $icon_pack); ?>
    <?php if ($params['type'] === 'solid' || $params['type'] === 'outline') { ?><span class="eltd-btn-background"></span><?php } ?>
</a>