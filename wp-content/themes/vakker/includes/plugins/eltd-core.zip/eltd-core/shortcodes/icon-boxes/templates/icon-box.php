<div class="eltd-icon-box">
    <div class="eltd-icon-box-inner">
        <span class="eltd-frame top-right-h"></span>
        <span class="eltd-frame top-right-v"></span>
        <span class="eltd-frame bottom-left-v"></span>
        <span class="eltd-frame bottom-left-h"></span>
        <div class="eltd-ib-title-holder">
            <h4 class="eltd-ib-title">
                <?php echo esc_html($title) ?>
            </h4>
            <?php echo vakker_eltd_execute_shortcode('eltd_icon', $icon_parameters); ?>
        </div>
        <div class="eltd-ib-text-holder">
            <?php echo esc_html($text); ?>
        </div>
    </div>
</div>