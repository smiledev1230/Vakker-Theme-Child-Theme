<div class="eltd-interactive-info-item">
    <div class="eltd-ii-item-initial">
        <div class="eltd-image-holder">
            <?php echo wp_get_attachment_image($initial_icon, 'full'); ?>
            <h4 class="eltd-iii-title" <?php echo vakker_eltd_get_inline_style($title_styles) ?>>
                <?php echo esc_html($title); ?>
            </h4>
        </div>
    </div>
    <div class="eltd-ii-item-hover">
        <div class="eltd-ii-item-hover-inner">
            <span class="eltd-frame top-right-v"></span>
            <span class="eltd-frame top-left-v"></span>
            <span class="eltd-frame bottom-left-v"></span>
            <span class="eltd-frame bottom-right-v"></span>
            <span class="eltd-frame top-right-h"></span>
            <span class="eltd-frame top-left-h"></span>
            <span class="eltd-frame bottom-left-h"></span>
            <span class="eltd-frame bottom-right-h"></span>
            <?php echo wp_get_attachment_image($hover_icon, 'full'); ?>
            <h4 class="eltd-iii-title">
                <?php echo esc_html($title); ?>
            </h4>
            <?php echo esc_html($text); ?>
        </div>
    </div>
</div>