<<?php echo esc_attr($title_tag); ?> class="eltd-accordion-title">
    <span class="eltd-accordion-mark">
		<span class="eltd_icon_plus icon_plus"></span>
		<span class="eltd_icon_minus icon_minus-06"></span>
	</span>
	<span class="eltd-tab-title"><?php echo esc_html($title); ?></span>
</<?php echo esc_attr($title_tag); ?>>
<div class="eltd-accordion-content">
	<div class="eltd-accordion-content-inner">
		<?php echo do_shortcode($content); ?>
	</div>
</div>