<?php if($image != '') { ?>
    <div class="eltd-client-holder <?php echo esc_attr($class); ?>" <?php echo vakker_eltd_get_inline_style($client_styles); ?>>
        <div class="eltd-client-holder-inner">
            <div class="eltd-client-image-holder">
                <?php if($link != '') { ?>
                <a href="<?php echo esc_url($link); ?>" target="<?php echo esc_attr($link_target); ?>">
                    <?php } else { ?>
                    <span class="eltd-client-image-nolink">
                <?php } ?>
                        <span class="eltd-client-image">
						<img src="<?php echo esc_url($image); ?>" alt="<?php echo esc_url($image_alt); ?>"/>
					</span>
                        <?php if($hover_image != '') { ?>
                            <span class="eltd-client-hover-image">
							<img src="<?php echo esc_url($hover_image); ?>" alt="<?php echo esc_url($hover_image_alt); ?>"/>
						</span>
                        <?php } ?>
                        <?php if($link != '') { ?>
                </a>
            <?php } else { ?>
                </span>
            <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>