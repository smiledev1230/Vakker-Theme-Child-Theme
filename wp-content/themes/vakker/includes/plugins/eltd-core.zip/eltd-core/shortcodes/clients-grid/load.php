<?php
require_once ELATED_CORE_SHORTCODES_PATH.'/clients-grid/clients.php';
require_once ELATED_CORE_SHORTCODES_PATH.'/clients-grid/client.php';
require_once ELATED_CORE_SHORTCODES_PATH.'/clients-grid/functions.php';

