<div class="eltd-info-box">
    <span class="eltd-frame top-left-v"></span>
    <span class="eltd-frame top-left-h"></span>
    <span class="eltd-frame bottom-right-v"></span>
    <span class="eltd-frame bottom-right-h"></span>
    <div class="eltd-info-box-inner">
        <div class="eltd-ib-title-holder">
            <<?php echo esc_html($title_tag); ?>
            class="eltd-ib-title"> <?php echo esc_html($title) ?> </<?php echo esc_html($title_tag); ?>>
        </div>
        <div class="eltd-ib-text">
            <?php echo esc_html($text); ?>
        </div>
        <?php if (!empty($button_link)) { ?>
            <div class="eltd-ib-button-holder">
                <?php echo vakker_eltd_execute_shortcode('eltd_button', array(
                    'type' => 'simple',
                    'link' => $button_link,
                    'text' => $button_text
                )); ?>
            </div>
        <?php } ?>
    </div>
</div>
